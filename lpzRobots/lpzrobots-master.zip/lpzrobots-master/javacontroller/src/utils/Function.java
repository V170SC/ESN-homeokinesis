package utils;

public interface Function {
	public double func(double x);
}
