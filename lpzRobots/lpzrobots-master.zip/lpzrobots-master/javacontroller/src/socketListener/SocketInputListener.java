package socketListener;

public interface SocketInputListener {
	
	public void socketGetsInput(SocketEvent event);

}
