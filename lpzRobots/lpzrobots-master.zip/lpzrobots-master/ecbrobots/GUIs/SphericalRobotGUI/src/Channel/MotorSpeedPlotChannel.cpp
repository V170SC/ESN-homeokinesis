
#include "MotorSpeedPlotChannel.h"
#include <iostream>


MotorSpeedPlotChannel::MotorSpeedPlotChannel(std::string name) : AbstractPlotChannel(name)
{
//   std::cout << "new MotorSpeedChannel created: " << name << std::endl;
}

MotorSpeedPlotChannel::~ MotorSpeedPlotChannel()
{
}
