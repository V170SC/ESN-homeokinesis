
#include "IRPlotChannel.h"
#include <iostream>

IRPlotChannel::IRPlotChannel(std::string name) : AbstractPlotChannel(name)
{
//   std::cout << "new IRPlotChannel created: " << name << std::endl;
}

IRPlotChannel::~ IRPlotChannel()
{
}

