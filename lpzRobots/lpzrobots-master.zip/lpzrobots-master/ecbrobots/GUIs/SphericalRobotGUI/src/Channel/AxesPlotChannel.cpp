
#include "AxesPlotChannel.h"

AxesPlotChannel::AxesPlotChannel(std::string name) : AbstractPlotChannel(name) {

}

AxesPlotChannel::~ AxesPlotChannel()
{
}
