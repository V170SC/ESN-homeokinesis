
#ifndef __DEFAULT_PLOT_CHANNEL_H__
#define __DEFAULT_PLOT_CHANNEL_H__

#include "AbstractPlotChannel.h"

class DefaultPlotChannel : public AbstractPlotChannel
{
public:
  
  DefaultPlotChannel(std::string name);
  virtual ~DefaultPlotChannel();
  
protected:
  
  
  
private:
  
  
};

#endif
