
#include "TiltPlotChannel.h"


TiltPlotChannel::TiltPlotChannel(std::string name):AbstractPlotChannel(name)
{
}

TiltPlotChannel::~ TiltPlotChannel()
{
}
