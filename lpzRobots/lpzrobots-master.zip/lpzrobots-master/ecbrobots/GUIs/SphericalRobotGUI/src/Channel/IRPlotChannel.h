
#ifndef __IR_PLOT_CHANNEL_H__
#define __IR_PLOT_CHANNEL_H__

#include "AbstractPlotChannel.h"

class IRPlotChannel : public AbstractPlotChannel
{
public:
  IRPlotChannel(std::string name);
  virtual ~IRPlotChannel();

protected:
  
  
private:
  
  
  
};

#endif
