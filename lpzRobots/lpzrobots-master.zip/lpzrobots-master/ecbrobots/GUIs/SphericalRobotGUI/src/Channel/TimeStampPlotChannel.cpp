
#include "TimeStampPlotChannel.h"

TimeStampPlotChannel::TimeStampPlotChannel(std::string name) : AbstractPlotChannel ( name )
{
  
}

TimeStampPlotChannel::~ TimeStampPlotChannel()
{
}
