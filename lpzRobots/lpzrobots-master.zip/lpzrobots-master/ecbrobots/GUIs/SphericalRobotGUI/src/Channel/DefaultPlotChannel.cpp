
#include "DefaultPlotChannel.h" 

DefaultPlotChannel::DefaultPlotChannel(std::string name) : AbstractPlotChannel(name)
{
  
}

DefaultPlotChannel::~ DefaultPlotChannel()
{
}
