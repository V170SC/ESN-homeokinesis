
#ifndef __MOTOR_CURRENT_PLOT_CHANNEL_H__
#define __MOTOR_CURRENT_PLOT_CHANNEL_H__

#include "AbstractPlotChannel.h"

class MotorCurrentPlotChannel : public AbstractPlotChannel
{
  
public:
  MotorCurrentPlotChannel(std::string name);
  virtual ~MotorCurrentPlotChannel();
  
protected:
  
  
private:
  
  
  
};



#endif
