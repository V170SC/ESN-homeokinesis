
#include "MotorCurrentPlotChannel.h"

MotorCurrentPlotChannel::MotorCurrentPlotChannel(std::string name) : AbstractPlotChannel(name)
{
}


MotorCurrentPlotChannel::~ MotorCurrentPlotChannel()
{
}
