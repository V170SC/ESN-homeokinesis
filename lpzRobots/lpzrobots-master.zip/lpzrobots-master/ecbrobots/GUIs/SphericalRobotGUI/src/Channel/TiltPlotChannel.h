
#ifndef __TILT_PLOT_CHANNEL_H__
#define __TILT_PLOT_CHANNEL_H__

#include "AbstractPlotChannel.h"

class TiltPlotChannel : public AbstractPlotChannel
{
  
public:
  TiltPlotChannel(std::string name);
  virtual ~TiltPlotChannel();
  
protected:
  
  
private:
  
  
  
};

#endif
