
#ifndef __AXES_PLOT_CHANNEL_H__
#define __AXES_PLOT_CHANNEL_H__

#include "AbstractPlotChannel.h"

class AxesPlotChannel : public AbstractPlotChannel
{
  
public:
  AxesPlotChannel(std::string name);
  virtual ~AxesPlotChannel();
  
protected:
  
  
private:
  
  
  
};

#endif
