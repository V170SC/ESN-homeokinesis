
#ifndef __MOTOR_SPEED_PLOT_CHANNEL_H__
#define __MOTOR_SPEED_PLOT_CHANNEL_H__

#include "AbstractPlotChannel.h"

class MotorSpeedPlotChannel : public AbstractPlotChannel
{
  
public:
  MotorSpeedPlotChannel(std::string name);
  virtual ~MotorSpeedPlotChannel();
  
protected:
  
  
private:
  
  
  
};

#endif
